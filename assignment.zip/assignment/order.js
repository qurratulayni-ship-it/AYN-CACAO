
let cart = JSON.parse(localStorage.getItem("cart")) || [];


function displayCart() {

    const cartItems = document.getElementById("cartItems");
    const emptyCart = document.getElementById("emptyCart");

    cartItems.innerHTML = "";


    if (cart.length === 0) {

        emptyCart.style.display = "block";
        cartItems.style.display = "none";

    } else {

        emptyCart.style.display = "none";
        cartItems.style.display = "block";

    }


    cart.forEach(function(item, index) {

        let itemTotal = item.price * item.quantity;

        cartItems.innerHTML += `

            <div class="cart-item">

                <div class="item-details">

                    <h3>${item.name}</h3>

                    <p>RM${Number(item.price).toFixed(2)}</p>

                    <button class="remove-btn"
                        onclick="removeItem(${index})">
                        Remove
                    </button>

                </div>


                <div class="quantity-control">

                    <button onclick="changeQuantity(${index}, -1)">
                        -
                    </button>

                    <span>${item.quantity}</span>

                    <button onclick="changeQuantity(${index}, 1)">
                        +
                    </button>

                </div>


                <div class="item-total">
                    RM${itemTotal.toFixed(2)}
                </div>

            </div>

        `;

    });


    updateSummary();

}

function changeQuantity(index, amount) {

    cart[index].quantity += amount;

    if (cart[index].quantity <= 0) {

        cart.splice(index, 1);

    }

    saveCart();

}

function removeItem(index) {

    cart.splice(index, 1);

    saveCart();

}


function saveCart() {

    localStorage.setItem("cart", JSON.stringify(cart));

    displayCart();

}


function updateSummary() {

    let totalItems = 0;
    let subtotal = 0;


    cart.forEach(function(item) {

        totalItems += Number(item.quantity);

        subtotal += Number(item.price) * Number(item.quantity);

    });


    document.getElementById("totalItems").textContent = totalItems;

    document.getElementById("subtotal").textContent =
        "RM" + subtotal.toFixed(2);

    document.getElementById("total").textContent =
        "RM" + subtotal.toFixed(2);

    document.getElementById("cartCount").textContent = totalItems;

}


function checkout() {

    if (cart.length === 0) {

        alert("Your cart is empty! Please add some products first.");

    } else {

        alert("Thank you for choosing AYNÉ CACAO! ♡");

    }

}


displayCart();
