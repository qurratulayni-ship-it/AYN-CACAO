
function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    let totalItems = 0;

    cart.forEach(function(item) {
        totalItems += Number(item.quantity);
    });

    let cartCount = document.getElementById("cartCount");

    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}

document.addEventListener("DOMContentLoaded", function() {
    updateCartCount();
});
